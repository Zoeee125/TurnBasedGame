﻿using TurnBasedGame.Classes;
using TurnBasedGame.Classes.Logging;

namespace TurnBasedGame.Classes.Objects
{
    /// <summary>
    /// Represents the monster in the game
    /// </summary>
    public class Monster : Creature
    {
        /// <summary>
        /// Creates a Monster which can move, attack and interact with near items.
        /// </summary>
        /// <param name="position">X and Y position of the monster.</param>
        /// <param name="name">The name of a monster.</param>
        /// <param name="health">Amount of health points.</param>
        /// <param name="baseDamage">Base damage of monsters attack without any weapon.</param>
        /// <param name="baseDefense">Base defense of a monster without any armor.</param>
        /// <param name="logger">Games logger.</param>
        public Monster((int x, int y) position,
                      string name,
                      int health,
                      int baseDamage,
                      int baseDefense,
                      ILogger logger)
            : base(position: position,
                  name: name,
                  health: health,
                  baseDamage: baseDamage,
                  baseDefense: baseDefense,
                  logger: logger)
        {
        }

        /// <summary>
        /// Monster is able to move on the game field.
        /// </summary>
        /// <param name="x">The X of position of the move.</param>
        /// <param name="y">The Y of position of the move.</param>
        public override void Move(int x, int y)
        {
            Position = (Position.X + x, Position.Y + y);
            _logger.Log(LogLevel.Debug, $"{Name} moved to {Position}");
        }
    }
}