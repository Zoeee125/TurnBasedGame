﻿using System.Xml.Linq;
using TurnBasedGame.Classes.Logging;
using TurnBasedGame.Classes.Objects;

using TurnBasedGame.Classes;

/// <summary>
/// Represents the player character in the game.
/// Can move, attack, and interact with nearby items.
/// </summary>
public class Player : Creature
{
    /// <summary>
    /// Creates a Player which can move, attack and interact with near items.
    /// </summary>
    /// <param name="position">X and Y position of the player.</param>
    /// <param name="name">The name of a player.</param>
    /// <param name="lifePoints">Amount of health points.</param>
    /// <param name="baseDamage">Base damage of players attack without any weapon.</param>
    /// <param name="baseDefense">Base defense of a player without any armor.</param>
    /// <param name="logger">Games logger.</param>
    public Player((int x, int y) position,
                string name,
                int lifePoints,
                int baseDamage,
                int baseDefense,
                ILogger logger)
        : base(position, name, lifePoints, baseDamage, baseDefense, logger)
    {
    }

    /// <summary>
    /// Player is able to move on the game field. 
    /// This method is a template method in create and here is specially implemented for player
    /// </summary>
    /// <param name="x">The X of position of the move.</param>
    /// <param name="y">The Y of position of the move.</param>
    public override void Move(int x, int y)
    {
        Position = (Position.X + x, Position.Y + y);
        _logger.Log(LogLevel.Info, $"{Name} moved to {Position}");
    }


    /// <summary>
    /// Gets nearby lootable items at the player's current position.
    /// </summary>
    /// <param name="world">The game world.</param>
    /// <returns>A collection of lootable objects at the player's position.</returns>
    public IEnumerable<WorldObject> GetNearbyItems(World world)
    {
        return world.GetObjectsAt(Position)
                  .Where(obj => obj != this && obj.Lootable);
    }
}
