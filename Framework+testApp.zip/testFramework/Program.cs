﻿using System;
using System.Linq;
using TurnBasedGame.Classes;
using TurnBasedGame.Classes.Logging;
using TurnBasedGame.Classes.Objects;

namespace TurnBasedGame.Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Game Test ===");
            Console.WriteLine("Game init...\n");

            // 1. Init of loggers
            var logger = InitializeLogger();
            var world = InitializeWorld(logger);

            // 2. Make player
            var player = CreatePlayer(logger);
            var enemy = CreateEnemy(logger);

            world.AddCreature(player);
            world.AddCreature(enemy);

            // 3. Make items
            CreateWorldItems(world, logger);

            // 4. Main loop
            GameLoop(world, player, enemy, logger);
        }

        static ILogger InitializeLogger()
        {
            var logger = new GameLogger();
            logger.MinimumLevel = LogLevel.Debug;
            logger.AddListener(new ConsoleLogger());
            logger.AddListener(new FileLogger("game_log.txt"));

            logger.Log(LogLevel.Debug, $"Logger: {logger}");

            return logger;
        }

        static World InitializeWorld(ILogger logger)
        {
            // Load configuration
            ConfigManager.LoadConfig();

            var world = new World(logger);

            logger.Log(LogLevel.Info, $"World created ({ConfigManager.MaxX}x{ConfigManager.MaxY})");
            logger.Log(LogLevel.Info, $"Difficulty: {ConfigManager.Difficulty}");

            return world;
        }

        static Player CreatePlayer(ILogger logger)
        {
            var player = new Player(
                position: (0, 0),
                name: "Hero",
                lifePoints: 100,
                baseDamage: 10,
                baseDefense: 5,
                logger: logger
            );

            // Add observers
            player.OnDamageTaken += (creature, damage) =>
                logger.Log(LogLevel.Warning, $"{creature.Name} took damage: {damage}");

            player.OnCreatureDied += creature =>
                logger.Log(LogLevel.Error, $"{creature.Name} died!");

            logger.Log(LogLevel.Info, $"Player {player.Name} created");
            return player;
        }

        static Monster CreateEnemy(ILogger logger)
        {
            var enemy = new Monster(
                position: (3, 2),
                name: "Goblin",
                health: 50,
                baseDamage: 7,
                baseDefense: 3,
                logger: logger
            );

            logger.Log(LogLevel.Info, $"Enemy {enemy.Name} created");
            return enemy;
        }

        static void CreateWorldItems(World world, ILogger logger)
        {
            var sword = new AttackItem(
                position: (3, 0),
                name: "Wooden sword",
                baseDamage: 5,
                logger: logger,
                range: 1,
                damageType: DamageType.Physical,
                criticalChance: 10,
                durability: 100
            );

            var potion = new HealthPotion(
                position: (2, 0),
                name: "Common Health Potion",
                healAmount: 10,
                logger: logger
            );

            var armor = new DefenceItem(
                position: (1, 0),
                name: "Leather armor",
                baseDefense: 3,
                logger: logger,
                defenseType: DefenseType.Physical,
                durability: 100
            );

            world.AddWorldObject(sword);
            world.AddWorldObject(potion);
            world.AddWorldObject(armor);

            logger.Log(LogLevel.Info, "World items created");
        }

        static void GameLoop(World world, Player player, Creature enemy, ILogger logger)
        {
            bool gameRunning = true;
            int turn = 1;

            while (gameRunning)
            {
                Console.WriteLine($"\n=== Turn {turn} ===");
                Console.WriteLine($"{player.Name}: {player.LifePoints} HP");
                Console.WriteLine($"{enemy.Name}: {enemy.LifePoints} HP");

                
                PlayerTurn(world, player, enemy, logger);

                // check end of game
                if (enemy.LifePoints <= 0)
                {
                    Console.WriteLine($"\n{enemy.Name} defeated! Victory!");
                    gameRunning = false;
                    continue;
                }

             
                EnemyTurn(enemy, player, logger);

                // check end of game
                if (player.LifePoints <= 0)
                {
                    Console.WriteLine($"\n{player.Name} defeated! Game over!");
                    gameRunning = false;
                }

                turn++;
            }

            logger.Log(LogLevel.Info, "Game ended");
        }

        static void PlayerTurn(World world, Player player, Creature enemy, ILogger logger)
        {
            Console.WriteLine("\n[PLAYERS TURN]");
            Console.WriteLine("1. Attack");
            Console.WriteLine("2. Pick up item");
            Console.WriteLine("3. Move");
            Console.Write("Choice: ");

            var input = Console.ReadKey().KeyChar;
            Console.WriteLine();

            switch (input)
            {
                case '1':
                    int damage = player.Attack(); //template method
                    enemy.ReceiveHit(damage);
                    break;

                case '2':
                    var item = player.GetNearbyItems(world).FirstOrDefault();
                    if (item != null)
                    {
                        player.Pick(item);
                        if (item is AttackItem weapon)
                        {
                            player.EquipWeapon(weapon);
                        }
                    }
                    else
                    {
                        logger.Log(LogLevel.Warning, "No items to pick");
                    }
                    break;

                case '3':
                    player.Move(1, 0); 
                    break;

                default:
                    logger.Log(LogLevel.Warning, "Wrong input");
                    break;
            }
        }

        static void EnemyTurn(Creature enemy, Player player, ILogger logger)
        {
            Console.WriteLine("\n[ENEMY TURN]");

            // always attacking
            int damage = enemy.Attack();
            player.ReceiveHit(damage);
        }
    }

}